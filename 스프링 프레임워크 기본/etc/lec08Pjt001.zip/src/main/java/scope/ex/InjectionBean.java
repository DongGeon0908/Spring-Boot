package scope.ex;

public class InjectionBean {

}
