package com.bs.lec20.mall;

public class Mall {
	
	private String gender;
	private boolean cookieDel;
	
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public boolean isCookieDel() {
		return cookieDel;
	}
	public void setCookieDel(boolean cookieDel) {
		this.cookieDel = cookieDel;
	}
	
}