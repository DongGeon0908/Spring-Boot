package operator;

public class CalSub implements Calculator {

	@Override
	public int sum(int firstNum, int secondNum) {
		return firstNum - secondNum;
	}

}