package operator;

public interface Calculator {
	public int sum(int firstNum, int secondNum);
}
