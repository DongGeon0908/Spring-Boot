package operator;

public class CalMul implements Calculator {

	@Override
	public int sum(int firstNum, int secondNum) {
		return firstNum * secondNum;
	}
	
}