package operator;

public class CalAdd implements Calculator{
	
	@Override
	public int sum(int firstNum, int secondNum) {
		return firstNum + secondNum;
	}

}