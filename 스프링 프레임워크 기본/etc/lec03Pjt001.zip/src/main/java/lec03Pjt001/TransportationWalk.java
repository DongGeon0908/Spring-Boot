package lec03Pjt001;

public class TransportationWalk {
	
	public void move() {
		System.out.println("도보로 이동 합니다.");
	}   

}