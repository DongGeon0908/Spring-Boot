package com.ho.lec24.member;

public class Member {
	
	private String memId;
	private String memPw;
	private String memMail;
	private int memPurcNum;
	
	public String getMemId() {
		return memId;
	}
	public void setMemId(String memId) {
		this.memId = memId;
	}
	public String getMemPw() {
		return memPw;
	}
	public void setMemPw(String memPw) {
		this.memPw = memPw;
	}
	public String getMemMail() {
		return memMail;
	}
	public void setMemMail(String memMail) {
		this.memMail = memMail;
	}
	public int getMemPurcNum() {
		return memPurcNum;
	}
	public void setMemPurcNum(int memPurcNum) {
		this.memPurcNum = memPurcNum;
	}
}