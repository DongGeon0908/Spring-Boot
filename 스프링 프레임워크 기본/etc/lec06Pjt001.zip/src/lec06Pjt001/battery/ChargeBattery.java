package lec06Pjt001.battery;

public class ChargeBattery implements Battery {

	@Override
	public int getBatteryValue() {

		return 0;
	}

}
