package lec06Pjt001.battery;

public class NormalBattery implements Battery {

	@Override
	public int getBatteryValue() {

		return 0;
	}

}
