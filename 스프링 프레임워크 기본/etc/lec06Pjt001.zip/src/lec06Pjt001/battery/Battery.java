package lec06Pjt001.battery;

public interface Battery {
	public int getBatteryValue();
}
